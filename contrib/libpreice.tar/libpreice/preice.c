/*
 * preice - Overloaded Xlib function XMapWindow
 *
 * Assign a process id to each mapped window
 *
 * Copyright (C) 2001 Coventive Technologies, Ltd.
 * Author: Mathias Hasselmann <mathias.hasselmann@gmx.de>
 * 
 * Based on xalf_launch.c (C) 2000 Peter �strand <altic@lysator.liu.se>
 * Based on scwm_set_pid_property.c (C) 1999 Toby Sargeant and Greg J. Badros
 */

#ifndef NDEBUG
#define DBG(msg) fprintf msg
#else
#define DBG(msg)
#endif

#define M(msg) (PACKAGE": "msg"\n")

#include <stdio.h>
#include <unistd.h>

#include <dlfcn.h>
#include <X11/Xlib.h>
#include <X11/Xatom.h>

/*****************************************************************************/

typedef Window (*FXMapWindow)(Display* display, Window w);
typedef Window (*FXMapRaised)(Display* display, Window w);

/*****************************************************************************/

static struct {
    void * handle;
    Window (*XMapWindow)(Display *, Window);
    Window (*XMapRaised)(Display *, Window);
} libX11 = { NULL, NULL, NULL };

static Atom XA_ICEWM_PID = None;

/*****************************************************************************/

void _init() {
    DBG((stderr, M("_init ")));

    if ((libX11.handle = dlopen("libX11.so",   RTLD_GLOBAL|RTLD_NOW)) != NULL ||
  	(libX11.handle = dlopen("libX11.so.6", RTLD_GLOBAL|RTLD_NOW)) != NULL) {
	if ((libX11.XMapWindow = dlsym(libX11.handle, "XMapWindow")) == NULL)
	    fprintf (stderr, M("%s"), dlerror());
	DBG((stderr, M("XMapWindow is at %p"), libX11.XMapWindow));

	if ((libX11.XMapRaised = dlsym (libX11.handle, "XMapRaised")) == NULL)
	    fprintf (stderr, M("%s"), dlerror());
	DBG((stderr, M("XMapRaised is at %p"), libX11.XMapRaised));
    } else
	fprintf (stderr, M("%s"), dlerror());
}

void _fini() {
    DBG((stderr, M("_fini ")));

    if (libX11.handle)
	dlclose(libX11.handle);
}

/*****************************************************************************/

static void set_ICEWM_PID(Display* dpy, Window win) {
    pid_t pid = getpid();

    if (XA_ICEWM_PID == None)
	XA_ICEWM_PID = XInternAtom(dpy, "_ICEWM_PID", False);

    XChangeProperty(dpy, win, XA_ICEWM_PID, XA_CARDINAL, 32,
    		    PropModeReplace, (unsigned char*) &pid, 1);
}

extern int XMapWindow(Display* dpy, Window win) {
    DBG ((stderr, M("XMapWindow on %s for window 0x%x by process %d"),
    	  DisplayString(dpy), (unsigned) win, getpid()));

    set_ICEWM_PID(dpy, win);

    return (libX11.XMapWindow ? libX11.XMapWindow(dpy, win)
    			      : BadImplementation);
}

extern int XMapRaised(Display* dpy, Window win) {
    DBG ((stderr, M("XMapRaised on %s for window 0x%x by process %d"),
    	  DisplayString(dpy), (unsigned) win, getpid()));

    set_ICEWM_PID(dpy, win);

    return (libX11.XMapRaised ? libX11.XMapRaised(dpy, win)
    			      : BadImplementation); 
}
